package com.yourname.colorceilings;

import com.yourname.colorceilings.block.ModBlocks;
import net.fabricmc.api.ModInitializer;

public class ColorCeilingsMod implements ModInitializer {
    @Override
    public void onInitialize() {
        ModBlocks.register();
    }
}
