package com.yourname.colorceilings;

import com.yourname.colorceilings.block.ModBlocks;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry;
import net.minecraft.block.Block;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class ColorCeilingsClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        for (int i = 0; i < ModBlocks.COLORS.length; i++) {
            String color = ModBlocks.COLORS[i];
            Block block = Registry.BLOCK.get(new Identifier("colorceilings", "colorceilings_" + color));
            int rgb = ModBlocks.COLOR_VALUES[i];
            ColorProviderRegistry.BLOCK.register((state, world, pos, tintIndex) -> rgb, block);
            ColorProviderRegistry.ITEM.register((stack, tintIndex) -> rgb, block.asItem());
        }
    }
}
