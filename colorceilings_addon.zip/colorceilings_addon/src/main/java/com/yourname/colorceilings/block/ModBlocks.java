package com.yourname.colorceilings.block;

import net.minecraft.block.Block;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class ModBlocks {
    public static final String[] COLORS = {"white","orange","magenta","light_blue","yellow","lime","pink","gray",
            "light_gray","cyan","purple","blue","brown","green","red","black"};

    public static final int[] COLOR_VALUES = {
            0xF9FFFE, 0xF9801D, 0xC74EBD, 0x3AB3DA,
            0xFED83D, 0x80C71F, 0xF38BAA, 0x474F52,
            0x9D9D97, 0x169C9C, 0x8932B8, 0x3C44AA,
            0x835432, 0x5E7C16, 0xB02E26, 0x1D1D21
    };

    public static final Block[] COLORED_CEILINGS = new Block[16];

    public static void register() {
        Block originalCeiling = Registry.BLOCK.get(new Identifier("mtr", "ceiling_no_light"));

        for (int i = 0; i < COLORS.length; i++) {
            String color = COLORS[i];
            Block block = originalCeiling;
            Identifier id = new Identifier("colorceilings", "ceiling_no_light_" + color);
            Registry.register(Registry.BLOCK, id, block);
            Registry.register(Registry.ITEM, id, new BlockItem(block, new Item.Settings().group(ItemGroup.BUILDING_BLOCKS)));
            COLORED_CEILINGS[i] = block;
        }
    }

    public static int getColor(String colorName) {
        for (int i = 0; i < COLORS.length; i++) {
            if (COLORS[i].equals(colorName)) return COLOR_VALUES[i];
        }
        return 0xFFFFFF;
    }
}
